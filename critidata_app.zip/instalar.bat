@echo off
setlocal
echo ============================================
echo   CritiData - Instalador (Windows)
echo ============================================
echo.

:: Verificar que Python este instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python no esta instalado.
    echo Descargalo desde https://www.python.org/downloads/
    echo Al instalar, marca la casilla "Add Python to PATH".
    pause
    exit /b 1
)

echo Creando entorno virtual...
python -m venv .venv

echo Instalando dependencias...
.venv\Scripts\pip install --quiet -r requirements.txt

echo Instalando navegador Chromium para Playwright...
.venv\Scripts\python -m playwright install chromium

echo.
echo ============================================
echo   Instalacion completada.
echo   Para ejecutar: haz doble clic en ejecutar.bat
echo ============================================
pause
