# ============================================================
# MÓDULO: scraper_client.py
# ============================================================
# QUÉ HACE:
#   Automatiza el login en bionefro.com.ar y descarga los PDFs
#   de los protocolos del día anterior. Devuelve los PDFs en
#   base64 para que el backend de Railway los procese con Haiku.
#
# POR QUÉ corre localmente y no en el servidor:
#   Bionefro bloquea IPs fuera de Argentina. Este proceso necesita
#   la IP del consultorio del médico para poder hacer login.
#
# POR QUÉ Playwright:
#   El sitio usa Blazor Server (WebSockets) — no se puede
#   scrapear con requests simples. Playwright controla un
#   browser real invisible.
# ============================================================

import base64
import queue
from playwright.async_api import async_playwright
from datetime import datetime, timedelta


class CredencialesInvalidasError(Exception):
    pass


async def ejecutar_scraper_pdfs(
    usuario: str,
    password: str,
    log_queue: queue.Queue = None,
    desde: str = None,
) -> list[dict]:
    # Devuelve [{numero_pedido: str, pdf_base64: str}].
    # Raises CredencialesInvalidasError si el login falla.
    def log(msg):
        if log_queue:
            log_queue.put(msg)
        else:
            print(msg)

    pdfs = []

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True, slow_mo=300)
        context = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            )
        )
        page = await context.new_page()

        try:
            await _login(page, usuario, password, log)
            pedidos = await _obtener_protocolos(page, desde, log)

            for i, numero in enumerate(pedidos, 1):
                try:
                    pdf_bytes = await _descargar_pdf(page, numero)
                    pdf_b64 = base64.standard_b64encode(pdf_bytes).decode("utf-8")
                    pdfs.append({"numero_pedido": numero, "pdf_base64": pdf_b64})
                    log(f"  [{i}/{len(pedidos)}] {numero}  ({len(pdf_bytes):,} bytes)")
                except Exception as e:
                    log(f"  [{i}/{len(pedidos)}] {numero}  ERROR: {e}")

        finally:
            await browser.close()

    return pdfs


async def _login(page, usuario: str, password: str, log) -> None:
    await page.goto("https://resultados.bionefro.com.ar/login")
    await page.wait_for_load_state("networkidle")

    await page.click(".dropdown-toggle")
    await page.wait_for_selector("a.dropdown-item", state="visible")
    await page.click("a.dropdown-item:has-text('Colega')")
    await page.wait_for_timeout(1500)

    await page.locator("input[placeholder='Colega']").press_sequentially(usuario, delay=80)
    await page.locator("input[placeholder='Colega']").press("Tab")
    await page.wait_for_timeout(800)

    await page.locator("input[placeholder='Contraseña']").press_sequentially(password, delay=80)
    await page.locator("input[placeholder='Contraseña']").press("Tab")
    await page.wait_for_timeout(1000)

    await page.locator("input[placeholder='Contraseña']").press("Enter")

    try:
        await page.wait_for_url("**/listadoprotocolos**", timeout=20000)
    except Exception:
        raise CredencialesInvalidasError(
            f"Login fallido — verificá usuario y contraseña. URL actual: {page.url}"
        )

    log(f"Login OK.")


async def _obtener_protocolos(page, desde, log) -> list[str]:
    if desde is None:
        desde = (datetime.now() - timedelta(days=1)).strftime("%d/%m/%Y")
    hoy = datetime.now().strftime("%d/%m/%Y")

    url_busqueda = (
        f"https://resultados.bionefro.com.ar/listadoprotocolos"
        f"?Desde={desde}&Hasta={hoy}&Validado=TODOS"
    )
    log(f"Buscando protocolos del {desde} al {hoy}…")

    await page.goto(url_busqueda)
    await page.wait_for_load_state("networkidle")

    try:
        await page.wait_for_selector("a[href*='/pedido/']", timeout=15000)
    except Exception:
        log("No se encontraron protocolos en el rango de fechas.")
        return []

    numeros: set[str] = set()

    def extraer_numeros(links):
        for link in links:
            partes = link.split("/pedido/")
            if len(partes) > 1:
                numeros.add(partes[1].split("/")[0])

    links_iniciales = await page.eval_on_selector_all(
        "a[href*='/pedido/']",
        "elements => elements.map(e => e.href)"
    )
    extraer_numeros(links_iniciales)
    log(f"Pedidos en vista inicial: {len(numeros)}")

    historial_count = len(await page.query_selector_all("button:has-text('Historial')"))
    log(f"Botones Historial: {historial_count}")

    for i in range(historial_count):
        try:
            await page.goto(url_busqueda)
            await page.wait_for_load_state("networkidle")
            await page.wait_for_selector("button:has-text('Historial')", timeout=10000)

            botones = await page.query_selector_all("button:has-text('Historial')")
            if i >= len(botones):
                break

            await botones[i].click()
            await page.wait_for_load_state("networkidle")
            await page.wait_for_timeout(2000)

            links = await page.eval_on_selector_all(
                "a[href*='/pedido/']",
                "elements => elements.map(e => e.href)"
            )
            antes = len(numeros)
            extraer_numeros(links)
            log(f"Historial {i + 1}: +{len(numeros) - antes} nuevos. Total: {len(numeros)}")

        except Exception as e:
            log(f"Error en historial {i + 1}: {e}")

    log(f"Total protocolos únicos: {len(numeros)}")
    return list(numeros)


async def _descargar_pdf(page, numero_pedido: str) -> bytes:
    await page.goto(f"https://resultados.bionefro.com.ar/pedido/{numero_pedido}")
    await page.wait_for_load_state("networkidle")

    async with page.expect_download(timeout=15000) as download_info:
        await page.click("a:has-text('Descargar')")

    download = await download_info.value
    path = await download.path()
    with open(path, "rb") as f:
        return f.read()
