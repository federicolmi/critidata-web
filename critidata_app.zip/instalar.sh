#!/bin/bash
echo "============================================"
echo "  CritiData - Instalador (Mac)"
echo "============================================"
echo

# Verificar que Python 3 este instalado
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 no esta instalado."
    echo "Descargalo desde https://www.python.org/downloads/"
    exit 1
fi

echo "Creando entorno virtual..."
python3 -m venv .venv

echo "Instalando dependencias..."
.venv/bin/pip install --quiet -r requirements.txt

echo "Instalando navegador Chromium para Playwright..."
.venv/bin/python -m playwright install chromium

echo
echo "============================================"
echo "  Instalacion completada."
echo "  Para ejecutar: abre una terminal y corre ./ejecutar.sh"
echo "  O haz doble clic en ejecutar.sh"
echo "============================================"
