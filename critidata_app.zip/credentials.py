# ============================================================
# MÓDULO: credentials.py
# ============================================================
# QUÉ HACE:
#   Guarda y recupera credenciales de CritiData usando el
#   llavero del sistema operativo (Windows Credential Manager
#   en Windows, Keychain en Mac). El médico las ingresa una
#   sola vez y la app las recuerda sin archivos de texto.
#
#   Las credenciales de bionefro ya NO se guardan localmente.
#   Se obtienen desde el backend (GET /auth/lab-credentials)
#   después del login, porque el médico las configura en la
#   app móvil durante el onboarding.
# ============================================================

import keyring
import requests

_SERVICE = "CritiData"


def get_critidata_creds() -> tuple[str | None, str | None]:
    return (
        keyring.get_password(_SERVICE, "critidata_email"),
        keyring.get_password(_SERVICE, "critidata_password"),
    )


def save_critidata_creds(email: str, password: str) -> None:
    keyring.set_password(_SERVICE, "critidata_email", email)
    keyring.set_password(_SERVICE, "critidata_password", password)


def get_lab_creds_from_backend(backend_url: str, token: str) -> tuple[str | None, str | None]:
    """Devuelve (lab_usuario, lab_password) desde el backend.

    El médico configuró sus credenciales de laboratorio durante el
    onboarding en la app móvil. El backend las guarda cifradas y
    las devuelve descifradas a través de este endpoint protegido.
    """
    resp = requests.get(
        f"{backend_url}/auth/lab-credentials",
        headers={"Authorization": f"Bearer {token}"},
        timeout=15,
    )
    resp.raise_for_status()
    data = resp.json()
    return data["lab_usuario"], data["lab_password"]
