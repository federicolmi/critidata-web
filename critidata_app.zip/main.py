# ============================================================
# ARCHIVO: main.py
# ============================================================
# QUÉ HACE:
#   App de escritorio para que el médico suscriptor importe
#   sus resultados de bionefro con un solo click.
#
# FLUJO:
#   1. Primera vez → pide credenciales de CritiData y bionefro
#   2. Las guarda en el llavero del sistema operativo (keyring)
#   3. El médico hace click en "Ejecutar" cada vez que quiere importar
#   4. Si el login en bionefro falla, vuelve a pedir las credenciales
#
# POR QUÉ threading:
#   Playwright es bloqueante — correría en el hilo principal y
#   congelaría la ventana. El hilo de fondo corre asyncio.run()
#   y manda mensajes a la GUI via queue.Queue (thread-safe).
# ============================================================

import tkinter as tk
from tkinter import scrolledtext, messagebox
import threading
import asyncio
import queue

import requests

from config import BACKEND_URL
from credentials import (
    get_critidata_creds, save_critidata_creds,
    get_lab_creds_from_backend,
)
from scraper_client import ejecutar_scraper_pdfs, CredencialesInvalidasError


class CritiDataApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("CritiData · Importador")
        self.geometry("620x540")
        self.resizable(False, False)
        self.configure(bg="#f5f5f5")

        self._log_queue: queue.Queue = queue.Queue()
        self._build_ui()
        self._poll_queue()

    def _build_ui(self):
        # ── Barra superior ──────────────────────────────────────
        header = tk.Frame(self, bg="#0d1b2a", height=64)
        header.pack(fill=tk.X)
        header.pack_propagate(False)
        tk.Label(
            header, text="CritiData  ·  Importador",
            bg="#0d1b2a", fg="white",
            font=("Segoe UI", 15, "bold"),
        ).place(relx=0.5, rely=0.5, anchor="center")

        # ── Estado actual ────────────────────────────────────────
        self._status_var = tk.StringVar(value="Listo")
        tk.Label(
            self,
            textvariable=self._status_var,
            bg="#f5f5f5", fg="#666",
            font=("Segoe UI", 11),
            pady=14,
        ).pack()

        # ── Botones ──────────────────────────────────────────────
        btn_frame = tk.Frame(self, bg="#f5f5f5")
        btn_frame.pack(pady=4)

        self._btn_run = tk.Button(
            btn_frame,
            text="  Ejecutar  ",
            bg="#0d1b2a", fg="white",
            font=("Segoe UI", 13, "bold"),
            relief=tk.FLAT, bd=0,
            padx=24, pady=10,
            cursor="hand2",
            command=self._on_run,
        )
        self._btn_run.pack(side=tk.LEFT, padx=6)

        tk.Button(
            btn_frame,
            text="Configurar credenciales",
            bg="#e8edf2", fg="#444",
            font=("Segoe UI", 10),
            relief=tk.FLAT, bd=0,
            padx=12, pady=10,
            cursor="hand2",
            command=self._on_config,
        ).pack(side=tk.LEFT, padx=6)

        # ── Log ──────────────────────────────────────────────────
        log_outer = tk.Frame(self, bg="#f5f5f5", padx=16, pady=12)
        log_outer.pack(fill=tk.BOTH, expand=True)

        tk.Label(
            log_outer, text="Actividad",
            bg="#f5f5f5", fg="#aaa",
            font=("Segoe UI", 9),
        ).pack(anchor=tk.W)

        self._log = scrolledtext.ScrolledText(
            log_outer,
            state=tk.DISABLED,
            font=("Courier New", 9),
            bg="white", fg="#333",
            relief=tk.FLAT, bd=1,
            height=18,
        )
        self._log.pack(fill=tk.BOTH, expand=True)

    # ── Utilidades de log ────────────────────────────────────────

    def _append_log(self, msg: str):
        self._log.configure(state=tk.NORMAL)
        self._log.insert(tk.END, msg + "\n")
        self._log.see(tk.END)
        self._log.configure(state=tk.DISABLED)

    def _poll_queue(self):
        # Drena la queue cada 100 ms desde el hilo principal.
        while not self._log_queue.empty():
            self._append_log(self._log_queue.get_nowait())
        self.after(100, self._poll_queue)

    # ── Lógica principal ─────────────────────────────────────────

    def _on_run(self):
        crit_email, crit_pass = get_critidata_creds()

        if not crit_email or not crit_pass:
            if not self._ask_critidata_creds():
                return
            crit_email, crit_pass = get_critidata_creds()

        self._btn_run.config(state=tk.DISABLED)
        self._status_var.set("Ejecutando…")

        threading.Thread(
            target=self._run_task,
            args=(crit_email, crit_pass),
            daemon=True,
        ).start()

    def _run_task(self, crit_email, crit_pass):
        # Corre en un hilo de fondo — no bloquea la GUI.
        try:
            self._log_queue.put("─" * 48)

            # 1. Login en CritiData para obtener el token JWT
            self._log_queue.put("Autenticando en CritiData…")
            login_r = requests.post(
                f"{BACKEND_URL}/auth/login",
                data={"username": crit_email, "password": crit_pass},
                timeout=30,
            )
            login_r.raise_for_status()
            token = login_r.json()["token"]

            # 2. Obtener credenciales de bionefro desde el backend
            self._log_queue.put("Obteniendo credenciales de laboratorio…")
            bio_user, bio_pass = get_lab_creds_from_backend(BACKEND_URL, token)

            # 3. Scraping en bionefro con las credenciales obtenidas
            self._log_queue.put("Conectando a bionefro…")
            pdfs = asyncio.run(
                ejecutar_scraper_pdfs(bio_user, bio_pass, self._log_queue)
            )

            if not pdfs:
                self._log_queue.put("Sin resultados nuevos para importar.")
                self.after(0, lambda: self._status_var.set("Sin resultados nuevos"))
                return

            self._log_queue.put(
                f"{len(pdfs)} PDF(s) descargados. Enviando al servidor…"
            )

            # 4. Enviar PDFs al backend para extracción con Haiku
            resp = requests.post(
                f"{BACKEND_URL}/lab/procesar-pdfs-bionefro",
                json={"pdfs": pdfs},
                headers={"Authorization": f"Bearer {token}"},
                timeout=600,
            )
            resp.raise_for_status()
            data = resp.json()

            msg = (
                f"✓  Guardados: {data['guardados']} de {data['total']}  ·  "
                f"Pacientes nuevos: {data.get('pacientes_creados', 0)}"
            )
            self._log_queue.put(msg)
            self.after(0, lambda: self._status_var.set("Completado"))

        except CredencialesInvalidasError:
            self._log_queue.put("Error: credenciales de bionefro incorrectas.")
            self._log_queue.put("Actualizá tus credenciales en la app móvil (Configuración).")
            self.after(0, lambda: self._status_var.set("Error de credenciales"))

        except Exception as exc:
            self._log_queue.put(f"Error: {exc}")
            self.after(0, lambda: self._status_var.set("Error"))

        finally:
            self.after(0, lambda: self._btn_run.config(state=tk.NORMAL))

    # ── Dialogs ──────────────────────────────────────────────────

    def _ask_critidata_creds(self) -> bool:
        return CredentialDialog(
            self,
            title="Credenciales de CritiData",
            label1="Email",
            label2="Contraseña",
            on_save=save_critidata_creds,
        ).was_saved

    def _on_config(self):
        ConfigWindow(self)


class CredentialDialog(tk.Toplevel):
    # Modal para ingresar dos campos (usuario + contraseña).
    # on_save(v1, v2) se llama cuando el usuario confirma.
    def __init__(self, parent, title: str, label1: str, label2: str, on_save):
        super().__init__(parent)
        self.title(title)
        self.geometry("380x230")
        self.resizable(False, False)
        self.configure(bg="#f5f5f5")
        self.grab_set()
        self.was_saved = False

        tk.Label(
            self, text=title,
            bg="#f5f5f5",
            font=("Segoe UI", 12, "bold"),
            pady=12,
        ).pack()

        form = tk.Frame(self, bg="#f5f5f5", padx=24)
        form.pack(fill=tk.X)

        tk.Label(form, text=label1, bg="#f5f5f5", font=("Segoe UI", 10), anchor=tk.W).pack(fill=tk.X)
        self._e1 = tk.Entry(form, font=("Segoe UI", 11))
        self._e1.pack(fill=tk.X, pady=(0, 8))

        tk.Label(form, text=label2, bg="#f5f5f5", font=("Segoe UI", 10), anchor=tk.W).pack(fill=tk.X)
        self._e2 = tk.Entry(form, font=("Segoe UI", 11), show="•")
        self._e2.pack(fill=tk.X, pady=(0, 12))

        def _save():
            v1, v2 = self._e1.get().strip(), self._e2.get().strip()
            if not v1 or not v2:
                messagebox.showwarning("Campos requeridos", "Completá ambos campos.", parent=self)
                return
            on_save(v1, v2)
            self.was_saved = True
            self.destroy()

        tk.Button(
            self, text="Guardar",
            bg="#0d1b2a", fg="white",
            font=("Segoe UI", 11, "bold"),
            relief=tk.FLAT,
            padx=16, pady=6,
            cursor="hand2",
            command=_save,
        ).pack(pady=4)

        self._e1.focus()
        self.wait_window()


class ConfigWindow(tk.Toplevel):
    # Permite al médico actualizar sus credenciales de CritiData.
    # Las credenciales de bionefro se gestionan desde la app móvil.
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Configurar credenciales")
        self.geometry("340x160")
        self.resizable(False, False)
        self.configure(bg="#f5f5f5")
        self.grab_set()

        tk.Label(
            self, text="Credenciales de CritiData",
            bg="#f5f5f5", font=("Segoe UI", 11),
            pady=20,
        ).pack()

        tk.Button(
            self, text="Actualizar credenciales",
            bg="#e8edf2", fg="#333",
            font=("Segoe UI", 10),
            relief=tk.FLAT, padx=12, pady=8,
            cursor="hand2",
            command=lambda: [self.destroy(), parent._ask_critidata_creds()],
        ).pack(pady=4)

        tk.Label(
            self,
            text="Las credenciales de bionefro se\nconfiguran en la app móvil.",
            bg="#f5f5f5", fg="#aaa",
            font=("Segoe UI", 9),
            pady=8,
        ).pack()


if __name__ == "__main__":
    app = CritiDataApp()
    app.mainloop()
